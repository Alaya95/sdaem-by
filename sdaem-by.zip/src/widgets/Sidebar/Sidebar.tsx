import React from 'react';

export const Sidebar = () => {
    return (
        <select name="" id="">
            <option value="" id=''></option>
        </select>
    );
}
