export const CITIES = [
    { id: 1, name: "Минск", value: "minsk" },
    { id: 2, name: "Гродно", value: "grodno" },
    { id: 3, name: "Брест", value: "brest" },
    { id: 4, name: "Витебск", value: "vitebsk" },
    { id: 5, name: "Гомель", value: "gomel" },
    { id: 6, name: "Могилев", value: "mogilev" },
];

export const ROOMS = [
    { id: 1, name: "1 комн", value: "1" },
    { id: 2, name: "2 комн", value: "2" },
    { id: 3, name: "3 комн", value: "3" },
    { id: 4, name: "4 комн", value: "4" },
    { id: 5, name: "5 комн", value: "5" },
];
