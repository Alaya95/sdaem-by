import React from 'react';

export const Button = () => {
    return (
        <div></div>
    );
}
