import React from 'react';

export const Checkbox = () => {
    return (
        <div></div>
    );
}
