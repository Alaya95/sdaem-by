import React from 'react';
import {About} from "../../features/About/About";
import {Filters} from "../../widgets/Filters/Filters";
import cls from './Main.module.scss';

export const Main = () => {
  return (
    <div className={cls.main}></div>
  );
};
