import React from 'react';

export const Catalog = () => {
    return (
        <div></div>
    );
}
